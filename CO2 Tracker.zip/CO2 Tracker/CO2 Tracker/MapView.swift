//  MapView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/12/22.
//

import SwiftUI
import MapKit

// MapView struct manages and represents the map in the UI
struct MapView: UIViewRepresentable {
    
    @ObservedObject var locationViewModel: LocationViewModel
    let polylinePoints: [CLLocationCoordinate2D]
    let showUserLocation: Bool
    let onMapChanged: ((MKMapView) -> Void)?
    
    // Initializing the MapView with necessary data
   init(locationViewModel: LocationViewModel, polylinePoints: [CLLocationCoordinate2D], showUserLocation: Bool, onMapChanged: ((MKMapView) -> Void)? = nil) {
        self.locationViewModel = locationViewModel
        self.polylinePoints = polylinePoints
        self.showUserLocation = showUserLocation
        self.onMapChanged = onMapChanged
    }
    
    // Creating a MKMapView as the UIView to represent
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = showUserLocation
        if showUserLocation {
            mapView.setUserTrackingMode(.followWithHeading, animated: true)
        } else {
            mapView.setUserTrackingMode(.none, animated: false)
        }
        return mapView
    }
    
    // Function to update the MKMapView
    func updateUIView(_ uiView: MKMapView, context: Context) {
        uiView.delegate = context.coordinator
        uiView.showsUserLocation = showUserLocation
        
        // Creating a polyline to represent a path on the map
        let coordinates = polylinePoints
        let newPolyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        // Adding or updating the polyline in the map view
        if context.coordinator.polyline == nil {
            context.coordinator.polyline = newPolyline
            uiView.addOverlay(newPolyline)
        } else {
            uiView.removeOverlay(context.coordinator.polyline!)
            context.coordinator.polyline = newPolyline
            uiView.addOverlay(newPolyline)
        }
        
        // Executing the onMapChanged closure
        if let onMapChanged = onMapChanged {
            onMapChanged(uiView)
        }
        
        // Updating map view settings based on whether location tracking is active
        if locationViewModel.isRecording {
            uiView.isPitchEnabled = true
            uiView.showsBuildings = true
            uiView.showsCompass = false
//            setCameraPerspective(mapView: uiView)
        } else {
            uiView.isPitchEnabled = false
            uiView.showsBuildings = false
            uiView.showsCompass = true
            uiView.camera.pitch = 0
        }
    }
    
    
    // Function to update settings of the map view
    func updateMapViewSettings(_ mapView: MKMapView) {
        if locationViewModel.isRecording {
            mapView.isPitchEnabled = true
            mapView.showsBuildings = true
            mapView.showsCompass = false
            mapView.userTrackingMode = .followWithHeading
        } else {
            mapView.isPitchEnabled = false
            mapView.showsBuildings = false
            mapView.showsCompass = true
            if showUserLocation {
                mapView.userTrackingMode = .follow
            } else {
                mapView.userTrackingMode = .none
            }
        }
    }
    
    // Function to set the camera perspective on the map
    func setCameraPerspective(mapView: MKMapView) {
            if let userLocation = mapView.userLocation.location {
                let camera = MKMapCamera(lookingAtCenter: userLocation.coordinate,
                                         fromDistance: 2500,
                                         pitch: 60,
                                         heading: userLocation.course)
                mapView.setCamera(camera, animated: true)
            }
        }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self, onMapChanged: onMapChanged)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapView
        var onMapChanged: ((MKMapView) -> Void)?
        var polyline: MKPolyline?
        
        init(_ parent: MapView, onMapChanged: ((MKMapView) -> Void)?) {
            self.parent = parent
            self.onMapChanged = onMapChanged
        }
        
        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            onMapChanged?(mapView)
            
            if parent.showUserLocation {
                if parent.locationViewModel.isRecording {
                    mapView.userTrackingMode = .followWithHeading
                } else {
                    mapView.userTrackingMode = .follow
                }
            } else {
                mapView.userTrackingMode = .none
            }
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                renderer.strokeColor = .blue
                renderer.lineWidth = 2
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}
