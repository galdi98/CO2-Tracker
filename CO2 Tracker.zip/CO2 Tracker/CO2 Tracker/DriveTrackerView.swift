//  DriveTrackerView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/03/23.
//

import SwiftUI
import MapKit
import CoreLocationUI
import CoreData

// DriveTrackerView manages the functionality related to tracking user's drive
struct DriveTrackerView: View {
    
    @ObservedObject var locationViewModel: LocationViewModel
    @ObservedObject var saveDayModel: SaveDayModel
    @State private var showModal = false
    @Environment(\.managedObjectContext) var managedObjectContext
    @State private var distanceInKm: Double = 0.0
    @State private var averageSpeed: Double = 0.0
    @State private var lastDrive: Drive?
    @State private var debounceWorkItem: DispatchWorkItem?
    @State private var mapView: MKMapView?
    @State private var lastDriveLocality: String?
    
    var body: some View {
        ZStack {
            MapView(locationViewModel: locationViewModel,
                                polylinePoints: locationViewModel.polylinePoints,
                                showUserLocation: true)
            .cornerRadius(10)
            .ignoresSafeArea()
            VStack {
                
                Spacer()
                
                // If location tracking is active, create a "Stop Recording" button
                if locationViewModel.isRecording {
                    Button("Stop Recording", action: {
                        locationViewModel.isRecording.toggle()
                        locationViewModel.stopDriveTracking {
                            getLastDrive()
                            showModal.toggle()
                        }
                    })
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.red)
                    .cornerRadius(10)
                    // Else, create a "Record Drive" button
                } else {
                    Button("Record Drive", action: {
                        locationViewModel.isRecording.toggle()
                        locationViewModel.startDriveTracking()
                    })
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(10)
                }
            }
        }
        .onAppear(perform: getLastDrive) // Get last drive on view appear
        // Show a DriveSummaryView as a modal sheet
        .sheet(isPresented: $showModal) {
            if let drive = lastDrive {
                DriveSummaryView(locationViewModel: locationViewModel, saveDayModel: saveDayModel, drive: drive, locality: lastDriveLocality)
                    .environment(\.managedObjectContext, self.managedObjectContext)
                    .onDisappear {
                        getLastDrive()
                    }
            } else {
                Text("No drives found")
            }
        }
    }
    
    func getLastDrive() {
        if let lastDrive = locationViewModel.getLastDrive(context: managedObjectContext) {
            self.distanceInKm = lastDrive.distanceTraveled
            self.averageSpeed = lastDrive.averageSpeed
            self.lastDrive = lastDrive

            // Fetch the locality for the last drive
            if let lastLatitude = lastDrive.latitudeArray?.last,
               let lastLongitude = lastDrive.longitudeArray?.last {
                let destination = CLLocationCoordinate2D(latitude: lastLatitude, longitude: lastLongitude)
                locationViewModel.fetchLocality(for: destination) { locality in
                    DispatchQueue.main.async {
                        self.lastDriveLocality = locality
                    }
                }
            }
        }
    }
    
    func centerMapOnUserLocation() {
        if let userLocation = locationViewModel.lastSeenLocation {
            let region = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 100, longitudinalMeters: 100)
            locationViewModel.region = region
        }
    }
    
    private func updateUserLocation(mapView: MKMapView) {
        if locationViewModel.isRecording {
            mapView.userTrackingMode = .followWithHeading
        } else {
            mapView.userTrackingMode = .follow
        }
    }
}
