//
//  SettingsView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/12/22.
//

import SwiftUI
import CoreData

// SettingsView is responsible for displaying and managing user settings
struct SettingsView: View {
    
    // Variables for managing app's state and data
        @ObservedObject var saveDayModel: SaveDayModel
        @Environment(\.managedObjectContext) var viewContext
        @StateObject private var dataController = DataController()
        @State private var showAlert = false // State variable for showing first alert
        @State private var showAlert1 = false // State variable for showing second alert
    
    
    var body: some View {
        NavigationStack{
            List{
                // Section for user info
                Section(header: Text("Your Info")){
                    TextField("First Name", text: $saveDayModel.firstName)
                    TextField("Last Name", text: $saveDayModel.lastName)
                    TextField("Street", text: $saveDayModel.street)
                    TextField("City", text: $saveDayModel.city)
                    HStack{
                        TextField("State", text: $saveDayModel.state)
                        TextField("Zip Code", text: $saveDayModel.zipCode)
                    }
                    DatePicker("Birthdate", selection: $saveDayModel.birthdate, displayedComponents: .date)
                }
                // Section for car information
                Section(header: Text("Car information")){
                    VStack(alignment: .leading) {
                        Text("CO2 Emissions (g/km): \(Int(saveDayModel.gramsPerKilometre))")
                            .font(.headline)
                        Slider(value: $saveDayModel.gramsPerKilometre, in: 0...800, step: 1)
                            .tint(.green)
                            .padding(.horizontal)
                            .onChange(of: saveDayModel.gramsPerKilometre) { newValue in
                                saveDayModel.updateGramsPerKilometre(newValue: newValue)
                            }
                    }
                                }
                // Section for house appliances
                Section(header: Text("House appliances")){
                    Toggle("Gas(off)/Electric(on) Water Boiler", isOn: $saveDayModel.isBoilerElectric)
                    Toggle("I have a Dishwasher", isOn: $saveDayModel.haveDishwasher)
                    
                }
                Section(header: Text("Other")){
                    Button("Save User Information") {
                        showAlert = true
                    }
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Confirm"), message: Text("Are you sure you want to save this information?"), primaryButton: .default(Text("Save")) {
                            dataController.addUser(firstName: saveDayModel.firstName, lastName: saveDayModel.lastName, street: saveDayModel.street, city: saveDayModel.city, state: saveDayModel.state, zipCode: saveDayModel.zipCode, email: saveDayModel.email, birthdate: saveDayModel.birthdate, gramsPerKilometre: saveDayModel.gramsPerKilometre, context: viewContext)
                        }, secondaryButton: .cancel())
                    }
                    Button("Clear all days") {
                        showAlert1 = true
                    }
                    .alert(isPresented: $showAlert1) {
                        Alert(title: Text("Confirm"), message: Text("Are you sure you want to clear all days?"), primaryButton: .destructive(Text("Clear")) {
                            clearAllDays()
                            saveDayModel.addDummyData()
                        }, secondaryButton: .cancel())
                    }
                }
            }
            .navigationTitle("Settings")
        }
        .navigationViewStyle(StackNavigationViewStyle())

    }
    
    func clearAllDays() {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Day")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try viewContext.execute(batchDeleteRequest)
            try viewContext.save()
        } catch {
            print("Error deleting objects: \(error)")
        }
    }
    
    
    /**540g CO2e: by hand, using water sparingly and not too hot
     770g CO2e: in a dishwasher at 55°C
     990g CO2e: in a dishwasher at 65°C
     8000g CO2e: by hand, with extravagant use of water*/
}
