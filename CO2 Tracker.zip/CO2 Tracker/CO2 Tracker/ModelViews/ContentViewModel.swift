//
//  ContentModelView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/12/22.
//

import Foundation
import SwiftUI
import MapKit
import CoreLocationUI

class ContentViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    
    @Published var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 45.466, longitude: 10.848 ), span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005))
    
    let locationManager = CLLocationManager()
    
    let dataController = DataController()
    
    @State var isDriveSummaryPresented = false
    @State var distanceDriven: Double = 0.0
    
    
    var locations: [CLLocation] = []
    var totalDistance: CLLocationDistance = 0.0
    var polyline: MKPolyline?
    var startTime: Date?
    var endTime: Date?
    var averageSpeed: CLLocationSpeed = 0.0
    
    override init() {
        super.init()
        locationManager.delegate = self
    }
    
    func requestAllowWhenInUseLocaitonPermission(){
        locationManager.requestLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latestLocation = locations.last else {
            return
        }
        
        DispatchQueue.main.async {
            self.region = MKCoordinateRegion(center: latestLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005))
        }
        
        if let startTime = startTime {
            let distance = latestLocation.distance(from: locations.last!)
            totalDistance += distance
            let timeElapsed = Date().timeIntervalSince(startTime)
            let speed = distance / timeElapsed
            averageSpeed = (averageSpeed * Double(self.locations.count) + speed) / Double(self.locations.count + 1)
        }
        self.locations.append(latestLocation)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func startDriveTracking() {
        locations.removeAll()
        polyline = nil
        totalDistance = 0.0
        averageSpeed = 0.0
        startTime = Date()
        locationManager.startUpdatingLocation()
    }
    
    func stopDriveTracking() {
        let context = dataController.container.viewContext
        locationManager.stopUpdatingLocation()
        endTime = Date()
        isDriveSummaryPresented = true
        let distanceInKilometers = totalDistance / 1000
        distanceDriven = distanceInKilometers
        dataController.addDrive(date: endTime!, distanceTraveled: distanceDriven, context: context)
    }
}
