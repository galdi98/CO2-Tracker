import Foundation
import UIKit
import CoreData

class SaveDayModel: NSObject, ObservableObject {
    
    @Published var countToday: Int64 = 0
    @Published var co2Count: Int64 = 0
    @Published var numberOfShowers: Int = 0
    @Published var numberOfDishwashers:Int = 0
    @Published var numberOfWashes:Int = 0
    @Published var numberOfDryers:Int = 0
    @Published var isBoilerElectric: Bool = false
    @Published var haveDishwasher: Bool = false
    @Published var firstName: String = ""
    @Published var lastName: String = ""
    @Published var street: String = ""
    @Published var city: String = ""
    @Published var state: String = ""
    @Published var zipCode: String = ""
    @Published var email: String = ""
    @Published var gramsPerKilometre: Double = 0.0
    @Published var birthdate: Date = Date()
    
    @Published var dayAdded = false
    
    let dataController = DataController()
    
    private var timer: Timer?
    private var lastDayAdded: Date?
    
    override init() {
        super.init()
        
        // Fetch requests for days and app user data
        let context = self.dataController.container.viewContext
        let request1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Today")
        let request2 = NSFetchRequest<NSFetchRequestResult>(entityName: "AppUser")
        request2.fetchLimit = 1
        
        do {
            let result1 = try context.fetch(request1)
            if let today = result1.last as? Today {
                self.countToday = today.count
                self.numberOfShowers = Int(today.showers)
                self.numberOfDishwashers = Int(today.dishwash)
                self.numberOfWashes = Int(today.wash)
                self.numberOfDryers = Int(today.dryer)
            }
        } catch {
            print("Error fetching last day: \(error)")
        }
        do {
            let result2 = try context.fetch(request2)
            if let user = result2.last as? AppUser {
                self.firstName = user.firstName ?? ""
                self.lastName = user.lastName ?? ""
                self.street = user.street ?? ""
                self.city = user.city ?? ""
                self.state = user.state ?? ""
                self.zipCode = user.zipCode ?? ""
                self.email = user.email ?? ""
                self.birthdate = user.birthdate ?? Date()
                self.gramsPerKilometre = user.gramsPerKilometre
            }
        } catch {
            print("Error fetching last user: \(error)")
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func saveData() {
        UserDefaults.standard.set(countToday, forKey: "countToday")
        UserDefaults.standard.set(numberOfShowers, forKey: "numberOfShowers")
        UserDefaults.standard.set(numberOfDishwashers, forKey: "numberOfDishwashers")
        UserDefaults.standard.set(numberOfWashes, forKey: "numberOfWashes")
        UserDefaults.standard.set(numberOfDryers, forKey: "numberOfDryers")
        UserDefaults.standard.set(gramsPerKilometre, forKey: "gramsPerKilometre")
    }
    
    func loadData() {
        countToday = Int64(UserDefaults.standard.integer(forKey: "countToday"))
        numberOfShowers = UserDefaults.standard.integer(forKey: "numberOfShowers")
        numberOfDishwashers = UserDefaults.standard.integer(forKey: "numberOfDishwashers")
        numberOfWashes = UserDefaults.standard.integer(forKey: "numberOfWashes")
        numberOfDryers = UserDefaults.standard.integer(forKey: "numberOfDryers")
        gramsPerKilometre = UserDefaults.standard.double(forKey: "gramsPerKilometre")
    }
    
    func addDummyData() {
        let context = self.dataController.container.viewContext
        let calendar = Calendar.current
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd"
        let startDate = dateFormatter.date(from: "2023/01/01")!
        
        let endDate = calendar.date(byAdding: .day, value: -1, to: Date())!
        var currentDate = startDate
        
        while currentDate <= endDate {
            let randomCount = Int64.random(in: 1000...30000)
            self.dataController.addDay(date: currentDate, grams: randomCount, context: context)
            
            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate)!
        }
        
        do {
            try context.save()
        } catch {
            print("Error adding dummy data: \(error)")
        }
    }
    
    func updateGramsPerKilometre(newValue: Double) {
        gramsPerKilometre = newValue
        UserDefaults.standard.set(gramsPerKilometre, forKey: "gramsPerKilometre")
    }
    
}
