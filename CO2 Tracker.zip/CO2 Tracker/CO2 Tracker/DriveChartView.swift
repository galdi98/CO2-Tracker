//
//  DriveChartView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 28/03/23.
//

import SwiftUI
import MapKit

struct DriveChartView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.dismiss) var dismiss
    @StateObject private var driveLocalities = DriveLocalities()
    @State private var initialLocalitiesLoaded: Bool = false
    
    // List containing all the drive records
    var drives: [Drive]
    
    @StateObject private var saveDayModel = SaveDayModel()
    @ObservedObject var locationViewModel: LocationViewModel
    
    
    var body: some View {
        NavigationView {
            List {
                ForEach(drivesByDate().keys.sorted(), id: \.self) { date in
                    let formattedDate = formatDate(date)
                    Section(header: Text(formattedDate)) {
                        ForEach([date], id: \.self) { _ in
                                ForEach(drivesByDate()[date] ?? [], id: \.self.id) { drive in
                                    driveRow(drive: drive)
                            }
                        }
                        .onDelete(perform: { indexSet in
                            deleteDrive(at: indexSet, for: date)
                        })
                    }
                }
            }
            .listStyle(GroupedListStyle())
            .navigationTitle("Drive records")
            .onAppear {
                if !initialLocalitiesLoaded {
                    for drive in drives {
                        if driveLocalities.localities[drive.id ?? UUID()] == nil {
                            updateLocalities(for: drive)
                        }
                    }
                    initialLocalitiesLoaded = true
                }
            }
        }
    }
    
    // Function to reorder items
    func drivesByDate() -> [Date: [Drive]] {
        var drivesByDate: [Date: [Drive]] = [:]
        
        for drive in drives {
            let driveDate = drive.date ?? Date()
            let startOfDay = Calendar.current.startOfDay(for: driveDate)
            
            if var drivesOnDate = drivesByDate[startOfDay] {
                drivesOnDate.append(drive)
                drivesByDate[startOfDay] = drivesOnDate
            } else {
                drivesByDate[startOfDay] = [drive]
            }
        }
        
        return drivesByDate
    }
    
    // Function to display each row
    func driveRow(drive: Drive) -> some View {
        NavigationLink(destination: DriveSummaryView(locationViewModel: locationViewModel, saveDayModel: saveDayModel, drive: drive, locality: driveLocalities.localities[drive.id ?? UUID()] ?? nil)) {
            HStack {
                if let locality = driveLocalities.localities[drive.id ?? UUID()] {
                    Text(locality)
                } else {
                    Text("Loading...")
                }
                Spacer()
                Text("\(drive.distanceTraveled, specifier: "%.2f") Km")
            }
        }
    }


    
    func formatDate(_ date: Date?) -> String {
        guard let date = date else { return "Unknown Date" }
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .none
        return dateFormatter.string(from: date)
    }
    
    func deleteDrive(at offsets: IndexSet, for date: Date) {
        guard let drivesOnDate = drivesByDate()[date] else { return }
        
        for index in offsets {
            let driveToDelete = drivesOnDate[index]
            managedObjectContext.delete(driveToDelete)
        }
        
        do {
            try managedObjectContext.save()
        } catch {
            print("Error deleting drive: \(error)")
        }
    }
    // Locality fetching
    func updateLocalities(for drive: Drive) {
        guard let lastLatitude = drive.latitudeArray?.last,
              let lastLongitude = drive.longitudeArray?.last else {
            driveLocalities.localities[drive.id  ?? UUID()] = "Unknown"
            return
        }

        let destination = CLLocationCoordinate2D(latitude: lastLatitude, longitude: lastLongitude)
        locationViewModel.fetchLocality(for: destination) { locality in
            DispatchQueue.main.async {
                driveLocalities.localities[drive.id  ?? UUID()] = locality
            }
        }
    }
    
    class DriveLocalities: ObservableObject {
        @Published var localities: [UUID: String] = [:]
    }
}
