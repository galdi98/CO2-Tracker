//
//  HomeView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/12/22.
//

import SwiftUI
import CoreLocation
import CoreData
import Combine

// HomeView is responsible for displaying the user's profile and daily usage
struct HomeView: View {
    
    // Variables for managing app's state and data
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.dismiss) var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject private var saveDayModel: SaveDayModel
    @ObservedObject var locationViewModel: LocationViewModel
    @StateObject private var dataController = DataController()
    @Binding var distanceTraveled: CLLocationDistance
    @State private var drivingCO2Emissions: Double = 0.0
    
    
    var body: some View {
        
        // Main view stack
        NavigationStack() {
            VStack{
                // User's profile and counters
                HStack{
                    // CO2 emissions count
                    VStack{
                        Text("Hello, \(saveDayModel.firstName)!")
                            .padding(50)
                            .font(.headline)
                            .fontWeight(.thin)
                            .navigationBarTitle("CO₂ Tracker")
                        Spacer()
                        Text("\(saveDayModel.countToday + Int64(drivingCO2Emissions)) grams")
                            .padding(.bottom)
                            .fontWeight(.semibold)
                            .font(.headline)
                        Text("of equivalent CO₂")
                            .padding(.bottom)
                        Spacer()
                    }
                    Spacer()
                    // User's profile and reset button
                    VStack {
                        Image("profileImage")
                            .clipShape(Circle())
                            .overlay{
                                Circle().stroke(.green, lineWidth: 0.5)
                            }
                            .shadow(radius: 7)
                        Spacer()
                        // Resetting daily counters
                        Button("Reset counter"){
                            saveDayModel.countToday = 0
                            saveDayModel.numberOfDryers = 0
                            saveDayModel.numberOfDishwashers = 0
                            saveDayModel.numberOfShowers = 0
                            saveDayModel.numberOfWashes = 0
                        }
                        .buttonStyle(.bordered)
                        Button("Add day manually") {
                            dataController.addDay(date: Date(), grams: saveDayModel.countToday, context: managedObjectContext)
                            saveDayModel.dayAdded.toggle()
                            saveDayModel.countToday = 0
                            saveDayModel.numberOfDryers = 0
                            saveDayModel.numberOfDishwashers = 0
                            saveDayModel.numberOfShowers = 0
                            saveDayModel.numberOfWashes = 0
                        }
                        .buttonStyle(.bordered)
                        Spacer()
                        Spacer()
                    }
                }
                
                // Section for adjusting daily counters
                Section(header: Text("Daily Counters")) {
                    HStack {
                        Text("\(saveDayModel.numberOfShowers)")
                        Stepper ("Showers" ){
                            if saveDayModel.isBoilerElectric {
                                saveDayModel.countToday += 496
                            } else {
                                saveDayModel.countToday += 256
                            }
                            saveDayModel.numberOfShowers += 1
                            do {
                                try managedObjectContext.save()
                            } catch {
                                print("Error saving context: \(error.localizedDescription)")
                            }
                        } onDecrement: {
                            if saveDayModel.numberOfShowers > 0 {
                                if saveDayModel.isBoilerElectric {
                                    saveDayModel.countToday -= 496
                                } else {
                                    saveDayModel.countToday -= 256
                                }
                                saveDayModel.numberOfShowers -= 1
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    print("Error saving context: \(error.localizedDescription)")
                                }
                            }
                        }
                    }
                    HStack {
                        Text("\(saveDayModel.numberOfDishwashers)")
                        Stepper ("Dishwashing") {
                            if saveDayModel.haveDishwasher && !saveDayModel.isBoilerElectric {
                                saveDayModel.countToday += 880
                            } else if saveDayModel.haveDishwasher && saveDayModel.isBoilerElectric {
                                saveDayModel.countToday += 920
                            } else if !saveDayModel.haveDishwasher && !saveDayModel.isBoilerElectric {
                                saveDayModel.countToday += 4500
                            } else if !saveDayModel.haveDishwasher && saveDayModel.isBoilerElectric {
                                saveDayModel.countToday += 4900
                            }
                            saveDayModel.numberOfDishwashers += 1
                            do {
                                try managedObjectContext.save()
                            } catch {
                                print("Error saving context: \(error.localizedDescription)")
                            }
                        } onDecrement: {
                            if saveDayModel.numberOfDishwashers > 0 {
                                if saveDayModel.haveDishwasher && !saveDayModel.isBoilerElectric {
                                    saveDayModel.countToday -= 880
                                } else if saveDayModel.haveDishwasher && saveDayModel.isBoilerElectric {
                                    saveDayModel.countToday -= 920
                                } else if !saveDayModel.haveDishwasher && !saveDayModel.isBoilerElectric {
                                    saveDayModel.countToday -= 4500
                                } else if !saveDayModel.haveDishwasher && saveDayModel.isBoilerElectric {
                                    saveDayModel.countToday -= 4900
                                }
                                saveDayModel.numberOfDishwashers -= 1
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    print("Error saving context: \(error.localizedDescription)")
                                }
                            }
                        }
                    }
                    HStack {
                        Text("\(saveDayModel.numberOfWashes)")
                        Stepper ("Washing machine Cycles") {
                            saveDayModel.countToday += 1500
                            saveDayModel.numberOfWashes += 1
                            do {
                                try managedObjectContext.save()
                            } catch {
                                print("Error saving context: \(error.localizedDescription)")
                            }
                        } onDecrement: {
                            if saveDayModel.numberOfWashes > 0 {
                                saveDayModel.countToday -= 1500
                                saveDayModel.numberOfWashes -= 1
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    print("Error saving context: \(error.localizedDescription)")
                                }
                            }
                        }
                    }
                    HStack {
                        Text("\(saveDayModel.numberOfDryers)")
                        Stepper ("Dryers Cycles") {
                            saveDayModel.countToday += 1800
                            saveDayModel.numberOfDryers += 1
                            do {
                                try managedObjectContext.save()
                            } catch {
                                print("Error saving context: \(error.localizedDescription)")
                            }
                        } onDecrement: {
                            if saveDayModel.numberOfDryers > 0 {
                                saveDayModel.countToday -= 1800
                                saveDayModel.numberOfDryers -= 1
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    print("Error saving context: \(error.localizedDescription)")
                                }
                            }
                        }
                    }
                }
                .padding()
                .onAppear {
                    saveDayModel.loadData()
                }
                .onChange(of: scenePhase) { newPhase in
                    if newPhase == .background {
                        saveDayModel.saveData()
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 25).fill(colorScheme == .dark ? Color.black : Color.white).shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 15))
        }
        .navigationTitle("<Back")
        .onChange(of: distanceTraveled) { newValue in
            // Calculating driving CO2 emissions based on distance traveled
            drivingCO2Emissions = newValue * saveDayModel.gramsPerKilometre
        }
    }
}
