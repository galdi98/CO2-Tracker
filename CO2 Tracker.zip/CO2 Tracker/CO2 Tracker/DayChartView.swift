//
//  DayChartView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 28/03/23.
//

import SwiftUI
import Charts

struct DayChartView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject private var saveDayModel: SaveDayModel
    let days: [Day]
    @State private var chartData: [BarMark] = []
    @State var chartBy: String
    @State var n: Int

    // First list of days used for filtering
    var filteredCountsList: [Day] {
        days.filter { $0.grams >= 0 }.sorted(by: { $0.date ?? Date() > $1.date ?? Date() })
    }
    
    // Final list used for chart based on time period selected
    var selectedDays: [Day] {
        switch chartBy {
        case "Week":
            return Array(filteredCountsList.prefix(7))
        case "Month":
            return Array(filteredCountsList.prefix(30))
        case "Year":
            return Array(filteredCountsList.prefix(365))
        default:
            return filteredCountsList
        }
    }
    
    var body: some View {
        NavigationStack {
            VStack{
                Text("Latest Records")
                    .fontWeight(.semibold)
                    .font(.title)
                    .padding()
                Picker("", selection: $chartBy) {
                    Text("Week")
                        .tag("Week")
                    Text("Month")
                        .tag("Month")
                    Text("Year")
                        .tag("Year")
                }
                .pickerStyle(.segmented)
                .padding()
                .onChange(of: chartBy) { _ in
                    updateChartData()
                }
                Chart {
                    ForEach(chartData, id: \.id) { mark in
                        mark
                    }
                }
                .foregroundStyle(Color.pink.gradient)
                .padding()
                .cornerRadius(10)
                .onAppear {
                    updateChartData()
                }
                // Stats for the selected period
                
                HStack {
                    VStack(alignment: .leading) {
                        Text(String(format: "Average: \n%.0f Eq.g", selectedDays.map(\.grams).reduce(0.0) { $0 + Double($1) } / Double(selectedDays.count)))
                    }
                    Spacer()
                    Divider()
                    Spacer()
                    VStack {
                        Text("Max: \(selectedDays.map(\.grams).max() ?? 0) Eq.g\n")
                        Text("Min: \(selectedDays.map(\.grams).min() ?? 0) Eq.g")
                        
                    }
                }
                .padding()
                Divider()
                    .padding(.top)
                Text("List of all Records")
                    .fontWeight(.semibold)
                    .font(.title3)
                List {
                    ForEach(filteredCountsList) { day in
                        HStack {
                            Text(day.date ?? Date(), style: .date)
                            Spacer()
                            Text("\(day.grams) Eq.g")
                        }
                    }
                    .onDelete(perform: deleteDay)
                }
            }
        }
    }
    
    private func deleteDay(at offsets: IndexSet) {
        offsets.forEach { index in
            let dayToDelete = filteredCountsList[index]
            managedObjectContext.delete(dayToDelete)
        }
        
        do {
            try managedObjectContext.save()
        } catch {
            print("Error deleting day: \(error)")
        }
    }
    
    func updateChartData() {
        chartData = selectedDays.map { day in
            BarMark(
                x: .value("Day", day.date ?? Date(), unit: .day),
                y: .value("grams", day.grams)
            )
        }
    }
    
}

extension BarMark: Identifiable {
    public var id: UUID {
        return UUID()
    }
}



