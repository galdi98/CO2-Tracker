//
//  RecordView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 28/02/23.
//

import Foundation
import SwiftUI
import Charts

// Global variable to hold list of days
var countsList: [Day] = []

// RecordView is responsible for displaying charts of the user's CO2 emissions
struct RecordView: View {
    
    // Variables for managing app's state and data
        @Environment(\.managedObjectContext) var managedObjectContext
        @EnvironmentObject var dataController: DataController
        @EnvironmentObject private var saveDayModel: SaveDayModel
        @ObservedObject var locationViewModel: LocationViewModel
        
        @State private var countsList: [Day] = [] // List of days
        @State private var lastWeek: [Day] = [] // List of days in the last week
        @State private var drives: [Drive] = [] // List of drives
    
    var body: some View {
        VStack{
            // Tab view to switch between days and drives charts
            TabView {
                DayChartView(days: dataController.fetchDays(context: managedObjectContext), chartBy: "Week", n: 7)
                    .environmentObject(saveDayModel)
                    .tabItem {
                        Text("Days")
                        Image(systemName: "calendar")
                }
                DriveChartView(drives: dataController.fetchDrives(context: managedObjectContext), locationViewModel: locationViewModel)
                        .tabItem {
                            Text("Drives")
                            Image(systemName: "car.fill")
                    }
            }
            .pickerStyle(.segmented)
        }
    }
}

// Extension to the Date structure to create a date from year, month and day
extension Date {
    static func from(year: Int, month: Int, day: Int) -> Date {
        let components = DateComponents (year: year, month: month, day: day)
        return Calendar.current.date (from: components)!
    }
}
