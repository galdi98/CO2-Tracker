//
//  DriveSummaryView.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 03/04/23.
//

import SwiftUI
import MapKit

// View used in recordView and every time that a drive is completed
struct DriveSummaryView: View {
    
    @ObservedObject var locationViewModel: LocationViewModel
    @ObservedObject var saveDayModel: SaveDayModel
    let drive: Drive
    let locality: String?
    
    // Polyline list of coordinates
    var polylinePoints: [CLLocationCoordinate2D] {
        let latitudes = drive.latitudeArray ?? []
        let longitudes = drive.longitudeArray ?? []
        return zip(latitudes, longitudes).map { CLLocationCoordinate2D(latitude: $0.0, longitude: $0.1) }
    }
    
    // Emissions calculation based on g/Km var
    var co2Emissions: Double {
        return drive.distanceTraveled * Double(saveDayModel.gramsPerKilometre)
    }
    
    var body: some View {
        VStack {
            Text(locality ?? "Drive Summary")
                .font(.title)
                .padding(.top)
                .fontWeight(.bold)
            Spacer()
            Text("Distance: \(drive.distanceTraveled, specifier: "%.2f") Km")
                .font(.headline)
            Spacer()
            Text("Average speed: \(drive.averageSpeed, specifier: "%.2f") Km/h")
                .font(.headline)
            Spacer()
            Text("CO2 Emissions: \(co2Emissions, specifier: "%.2f") grams")
                .font(.headline)
            Spacer()
            Spacer()
            MapView(
                locationViewModel: locationViewModel,
                polylinePoints: polylinePoints,
                showUserLocation: false,
                onMapChanged: { mapView in
                    setMapRegion(polylinePoints: polylinePoints, mapView: mapView)
                }
            )
            .frame(height: 350)
            .cornerRadius(20)
            .padding(.horizontal)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 25).fill(Color(.systemBackground)).shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5))
        .navigationBarTitle("Date: \(drive.date ?? Date(), style: .date)", displayMode: .inline)
        .onAppear {
            if let lastCoordinate = polylinePoints.last {
                guard let lastLatitude = drive.latitudeArray?.last,
                      let lastLongitude = drive.longitudeArray?.last else {
                    return
                }
                let destination = CLLocationCoordinate2D(latitude: lastLatitude, longitude: lastLongitude)
                locationViewModel.fetchLocality(for: destination) { _ in }
            }
        }
    }
    
    
    
    func setMapRegion(polylinePoints: [CLLocationCoordinate2D], mapView: MKMapView) {
        guard !polylinePoints.isEmpty else { return }
        let polyline = MKPolyline(coordinates: polylinePoints, count: polylinePoints.count)
        
        let mapRect = polyline.boundingMapRect
        let edgePadding = UIEdgeInsets(top: 50, left: 50, bottom: 50, right: 50)
        let paddedRect = mapRect.insetBy(dx: -Double(edgePadding.left + edgePadding.right), dy: -Double(edgePadding.top + edgePadding.bottom))
        
        mapView.setVisibleMapRect(paddedRect, edgePadding: edgePadding, animated: true)
    }
    
    init(locationViewModel: LocationViewModel, saveDayModel: SaveDayModel, drive: Drive, locality: String?) {
        self.locationViewModel = locationViewModel
        self.saveDayModel = saveDayModel
        self.drive = drive
        self.locality = locality
    }
}
