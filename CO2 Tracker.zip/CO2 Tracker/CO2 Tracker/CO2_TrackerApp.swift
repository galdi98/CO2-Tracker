//
//  CO2_TrackerApp.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 15/12/22.
//

import SwiftUI

@main

struct CO2_TrackerApp: App {
    
    @StateObject private var dataController = DataController()
    @StateObject private var saveDayModel = SaveDayModel()
    @StateObject private var locationViewModel = LocationViewModel()
    
    
    var body: some Scene {
        WindowGroup {
            ContentView(distanceTraveled: .constant(0), locationViewModel: locationViewModel)
                .environment(\.managedObjectContext, dataController.container.viewContext)
                .environmentObject(saveDayModel)
                .environmentObject(dataController)
        }
    }

}
