// ContentView.swift
// CO2 Tracker
// Created by Francesco Galdiolo on 15/12/22.

// Importing the necessary modules
import SwiftUI
import MapKit
import CoreLocationUI

// Defining the ContentView struct which is a SwiftUI View
struct ContentView: View {
    
    // Declaring a private state variable 'colors' that is an array of SwiftUI 'Color'
    @State private var colors: [Color] = []
    // Declaring a binding variable 'distanceTraveled' that keeps track of the distance traveled
    @Binding var distanceTraveled: CLLocationDistance
    // Declaring an environment object 'saveDayModel' which is an instance of the SaveDayModel class
    @EnvironmentObject var saveDayModel: SaveDayModel
    // Declaring a state object 'locationViewModel' which is an instance of the LocationViewModel class
    @StateObject var locationViewModel: LocationViewModel
    
    // The body of the ContentView
    var body: some View {
        // A TabView that holds different tabs each representing a different view
        TabView() {
            // The home view which takes in the location view model and distance traveled as arguments
            HomeView(locationViewModel: locationViewModel, distanceTraveled: $distanceTraveled)
                // Attaching the 'saveDayModel' environment object to the HomeView
                .environmentObject(saveDayModel)
                .tabItem {
                    // The tab item configuration for the HomeView tab
                    Image(systemName: "house")
                    Text("Home")
                }
            // The drive tracker view which takes in the location view model and save day model as arguments
            DriveTrackerView(locationViewModel: locationViewModel, saveDayModel: saveDayModel)
                .tabItem{
                    // The tab item configuration for the DriveTrackerView tab
                    Image(systemName: "map")
                    Text("Drive Tracker")
                }
            // The record view which takes the location view model as an argument
            RecordView(locationViewModel: locationViewModel)
                .tabItem{
                    // The tab item configuration for the RecordView tab
                    Image(systemName: "books.vertical.fill")
                    Text("Records")
                }
            // The settings view which takes the save day model as an argument
            SettingsView(saveDayModel: saveDayModel)
                .tabItem {
                    // The tab item configuration for the SettingsView tab
                    Image(systemName: "gear")
                    Text("Settings")
                }
        }
        // Setting the background color of the TabView
        .background(Color(UIColor.systemGroupedBackground))
        // Making the TabView ignore safe area constraints
        .ignoresSafeArea()
        // Setting the navigation title of the ContentView
        .navigationTitle("CO2 Tracker")
        // Setting the accent color of the ContentView
        .accentColor(.green)
    }
}
