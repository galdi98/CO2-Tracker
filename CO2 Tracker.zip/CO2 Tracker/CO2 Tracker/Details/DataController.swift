//
//  File.swift
//  CO2 Tracker
//
//  Created by Francesco Galdiolo on 16/03/23.
//

import Foundation
import CoreData
import CoreLocation

// Class used to permanently store and retrieve data
class DataController: ObservableObject {
    
    let container = NSPersistentContainer (name: "CO2data")
    init() {
        container.loadPersistentStores { desc, error in
            if let error = error {
                print("Failed to load the data \(error.localizedDescription)")
            }
        }
    }
    
    func save(context: NSManagedObjectContext) {
        do {
            try context.save()
            print ("Data saved!!! WUHU!!!")
        } catch {
            print ("We could not save the data...")
        }
    }
    func addDay(date: Date, grams: Int64, context: NSManagedObjectContext) {
        let day = Day(context: context)
        day.id = UUID()
        day.date = date
        day.grams = grams
        
        save(context: context)
    }
    
    func editDay(day: Day, grams: Int64, context: NSManagedObjectContext){
        day.date = Date()
        day.grams = grams
        
        save(context: context)
    }
    
    func addUser(firstName: String, lastName: String, street: String, city: String, state: String, zipCode: String, email: String, birthdate: Date, gramsPerKilometre: Double, context: NSManagedObjectContext) {
        let user = AppUser(context: context)
        user.firstName = firstName
        user.lastName = lastName
        user.street = street
        user.city = city
        user.state = state
        user.zipCode = zipCode
        user.email = email
        user.birthdate = birthdate
        user.gramsPerKilometre = gramsPerKilometre
        
        do {
            try context.save()
        } catch {
            print("Error saving user: \(error)")
        }
    }
    
    func editUser(user: AppUser, firstName: String, lastName: String, email: String, street: String, city: String, state: String, zipCode: String, make: String, model: String, fuel: String, year: String, birthdate: Date, context: NSManagedObjectContext){
        
    }
    
    func fetchDays(context: NSManagedObjectContext) -> [Day] {
        let request: NSFetchRequest<Day> = Day.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "date", ascending: false)
        request.sortDescriptors = [sortDescriptor]
        do {
            let days = try context.fetch(request)
            return days
        } catch {
            print("Error fetching days: \(error.localizedDescription)")
            return []
        }
    }
    
    func fetchDrives(context: NSManagedObjectContext, sortBy: Drive.SortKey? = nil, sortAscending: Bool = true) -> [Drive] {
        let request: NSFetchRequest<Drive> = Drive.fetchRequest()

        if let sortKey = sortBy {
            let sortDescriptor = NSSortDescriptor(key: sortKey.rawValue, ascending: sortAscending)
            request.sortDescriptors = [sortDescriptor]
        }

        do {
            let drives = try context.fetch(request)
            return drives
        } catch {
            print("Error fetching drives: \(error)")
            return []
        }
    }

    
    func addDrive(date: Date, distanceTraveled: CLLocationDistance, averageSpeed: CLLocationSpeed, coordinates: [CLLocation], context: NSManagedObjectContext, completion: @escaping (Drive?) -> Void) {
        let drive = Drive(context: context)
        drive.date = date
        drive.distanceTraveled = distanceTraveled
        drive.averageSpeed = averageSpeed
        drive.id = UUID()
        
        let latitudes = coordinates.map { $0.coordinate.latitude }
        let longitudes = coordinates.map { $0.coordinate.longitude }
        drive.latitudeArray = latitudes
        drive.longitudeArray = longitudes
        
        do {
            try context.save()
            print("Drive saved successfully")
            completion(drive)
        } catch {
            print("Failed to save drive: \(error.localizedDescription)")
            completion(nil)
        }
    }
}

// Adding an enum inside the Drive entity for sort keys:
extension Drive {
    enum SortKey: String {
        case date = "date"
    }
}
